package com.tienda.client;

public class Tienda {

	public static void main(String[] args) {
		
		(new Gestion()).menu();
		
	}
}
